#include"listLL1.cpp"
//#include"listArr1.cpp"

int main(int argc, char const *argv[])
{
    L.init();
    L.display();
    int len = L.size/2;
    for(int i=0;i<L.size/2; i++){
        L.moveToPos(i);
        
        cout<<L.getValue()<<" ";
        L.moveToPos(L.size-i-1);
         
        cout<<L.getValue()<<" ";
    }
    if(L.size%2!=0){
        L.moveToPos(len);
        cout<<L.getValue();
    } 
    cout<<endl;

    return 0;
}
