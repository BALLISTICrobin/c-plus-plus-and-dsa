rbt.insert(10, "thors");
    rbt.insert(34, "Canute");
    rbt.insert(43, "Olaf");
    rbt.insert(15, "Einer");
    rbt.insert(40, "Olmar");