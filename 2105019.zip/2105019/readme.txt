Here I have made 2 header files with .h extension
 "Arr.h" and "LL.h", both of which has the class List which are implemented
 using Array and Linked List respectively.

 I am importing that List class from the header files to the
 "Arr.cpp" and "LL.cpp" respectively. Both the main functions are exactly the same
 with a little exception for the taking the init parameter function for the Arr.cpp implementation.

 For The Task 2 and Task 3 I have imported List from both Arr.hpp and LL.hpp. Either of them can be used by commenting out
 the other one and changing the part of init function a little bit. Thus, all the criteria for The
 proper implementation of abstract datatype has been met as the user wouldn't need to worry about how the list actually works on the inside.